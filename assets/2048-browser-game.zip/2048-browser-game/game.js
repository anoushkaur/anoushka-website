const container = document.getElementById("game-container");
let board = Array(4).fill().map(() => Array(4).fill(0));

function drawBoard() {
  container.innerHTML = "";
  board.forEach(row => {
    row.forEach(val => {
      const tile = document.createElement("div");
      tile.className = "tile";
      tile.textContent = val !== 0 ? val : "";
      container.appendChild(tile);
    });
  });
}

function addTile() {
  let options = [];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (board[r][c] === 0) options.push({ r, c });
    }
  }
  if (options.length === 0) return;
  const { r, c } = options[Math.floor(Math.random() * options.length)];
  board[r][c] = Math.random() < 0.9 ? 2 : 4;
}

function slide(row) {
  row = row.filter(val => val);
  for (let i = 0; i < row.length - 1; i++) {
    if (row[i] === row[i + 1]) {
      row[i] *= 2;
      row[i + 1] = 0;
    }
  }
  return row.filter(val => val).concat(Array(4 - row.filter(val => val).length).fill(0));
}

function rotateClockwise(b) {
  return b[0].map((_, i) => b.map(row => row[i]).reverse());
}

function rotateCounterClockwise(b) {
  return b[0].map((_, i) => b.map(row => row[3 - i]));
}

function handleMove(direction) {
  let rotated = board;
  if (direction === "ArrowUp") rotated = rotateCounterClockwise(board);
  if (direction === "ArrowRight") rotated = rotateClockwise(rotateClockwise(board));
  if (direction === "ArrowDown") rotated = rotateClockwise(board);

  let newBoard = rotated.map(slide);

  if (direction === "ArrowUp") newBoard = rotateClockwise(newBoard);
  if (direction === "ArrowRight") newBoard = rotateClockwise(rotateClockwise(newBoard));
  if (direction === "ArrowDown") newBoard = rotateCounterClockwise(newBoard);

  if (JSON.stringify(newBoard) !== JSON.stringify(board)) {
    board = newBoard;
    addTile();
    drawBoard();
  }
}

document.addEventListener("keydown", e => {
  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
    handleMove(e.key);
  }
});

addTile();
addTile();
drawBoard();
